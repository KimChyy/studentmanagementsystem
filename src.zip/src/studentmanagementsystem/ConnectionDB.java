/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author EJAT
 */
public class ConnectionDB {

    String sql;

    public ConnectionDB(String sql) {
        this.sql = sql;
    }

    public PreparedStatement tryConnect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection
        ("jdbc:mysql://localhost:3306/studentmanagementsystem", "root", "");
            return conn.prepareStatement(sql);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return null;
    }

}
