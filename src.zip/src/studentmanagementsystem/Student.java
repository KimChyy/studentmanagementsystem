/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author EJAT
 */

//(Student -> Person) inheritance
public class Student extends Person {
    private String name;
    private String email;
    private String phoneNo;
    private String studentId;
    private String icNo;
    private String block;
    private String address;
    private double fees;
    private String password;
    private Course course;
    private Faculty faculty;
    private Subject[] listSubject;

    public Student() {
    }

    public Student( String studentId, String icNo, String block, String address, double fees, String password, Course course, Faculty faculty, String name, String email, String phoneNo, Subject[] listSubject) {
        this.name = name;
        this.email = email;
        this.phoneNo = phoneNo;
        this.studentId = studentId;
        this.icNo = icNo;
        this.address = address;
        this.block = block;
        this.fees = fees;
        this.password = password;
        this.course = course;  // (Course > Student) aggregation
        this.faculty = faculty; // (Faculty > Student) aggregation
        this.listSubject = listSubject;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getPhoneNo() {
        return phoneNo;
    }

    @Override
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
    
    

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getIcNo() {
        return icNo;
    }

    public void setIcNo(String icNo) {
        this.icNo = icNo;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getFees() {
        return fees;
    }

    public void setFees(double fees) {
        this.fees = fees;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public Subject[] getListSubject() {
        return listSubject;
    }

    public void setListSubject(Subject[] listSubject) {
        this.listSubject = listSubject;
    }

  

   
    
    
    
}
