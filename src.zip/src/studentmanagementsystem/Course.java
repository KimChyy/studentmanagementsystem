/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author EJAT
 */
public class Course {

    private String name;
    private String courseId;
   
    private Faculty faculty;

    public Course() {
    }

    public Course(String name, String courseId, Faculty faculty) {
        this.name = name;
        this.courseId = courseId;
        // composition: kalau faculty takde, Course auto takde, (Faculty >> Course)
        this.faculty = new Faculty(faculty.getName(), faculty.getShortName());
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

}
