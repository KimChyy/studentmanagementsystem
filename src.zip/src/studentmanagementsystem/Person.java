/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author EJAT
 */
abstract public class Person {

  

    abstract public String getName();

    abstract public void setName(String name);

    abstract public String getEmail();

    abstract public void setEmail(String email);

    abstract public String getPhoneNo();

    abstract public void setPhoneNo(String phoneNo);
}
