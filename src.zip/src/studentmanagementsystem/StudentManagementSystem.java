/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementsystem;

import java.awt.Color;
import java.awt.Component;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;


/**
 *
 * @author EJAT
 */
public class StudentManagementSystem{
  

    /**
     * @param args the command line arguments
     */
    public static void notmain(String[] args) {
        // TODO code application logic here
        // test


        // test 2


        Scanner scan = new Scanner(System.in);
        System.out.print("Please Enter Your Role (1 = Admin, 2 = Student): ");
        String chooseRole = scan.nextLine();

        String exit = "No";

        // loop untuk exit system atau tak
        while (!exit.equals("Yes") && !exit.equals("yes")) {
            
            // loop untuk choose role admin atau student
            while (!chooseRole.equals("1") && !chooseRole.equals("2")) {
                System.out.print("Please Enter Your Role (1 = Admin, 2 = Student): ");
                chooseRole = scan.nextLine();
            }
            if (chooseRole.equals("1")) {
                System.out.println("You are Admin now");
                Admin adm1 = new Admin();
                
                System.out.println("Please Set Your Details");
                System.out.print("Enter Name: ");
                String name = scan.nextLine();
                // inherite the name from class Person
                adm1.setName(name);

                System.out.print("Enter Admin ID: ");
                String adminId = scan.nextLine();
                adm1.setAdminId(adminId);

                System.out.print("Enter Email: ");
                String email = scan.nextLine();
                adm1.setEmail(email);

                System.out.print("Enter Phone No: ");
                String phoneNo = scan.nextLine();
                adm1.setPhoneNo(phoneNo);

                System.out.println();
                System.out.println("Your Details");
                System.out.println("Your Name     : " + adm1.getName());
                System.out.println("Your ID       : " + adm1.getAdminId());
                System.out.println("Your Email    : " + adm1.getEmail());
                System.out.println("Your Phone No : " + adm1.getPhoneNo());
                System.out.println();

                System.out.print("Do you want to exit now? (Yes/No): ");
                exit = scan.nextLine();
                chooseRole = "3";


            } else if (chooseRole.equals("2")) {
                System.out.println("You are Student now");
                // polymorphism
                Person std1 = new Student();
                System.out.println("Please enter your details");

                System.out.print("Enter Name: ");
                String name = scan.nextLine();
                ((Student) std1).setName(name);

                System.out.print("Enter Student ID: ");
                String studentId = scan.nextLine();
                ((Student) std1).setStudentId(studentId);

                System.out.print("Enter Email Student: ");
                String email = scan.nextLine();
                ((Student) std1).setEmail(email);

                System.out.print("Enter IC no: ");
                String icNo = scan.nextLine();
                ((Student) std1).setIcNo(icNo);

                System.out.println();

                System.out.println("Your Student Details");
                System.out.println("Your Name: " + ((Student) std1).getName());
                System.out.println("Your Student ID: " + ((Student) std1).getStudentId());
                System.out.println("Your Email Student: " + ((Student) std1).getEmail());
                System.out.println("Your IC No: " + ((Student) std1).getIcNo());
                System.out.println();

                System.out.print("Do you want to exit now? (Yes/No): ");
                exit = scan.nextLine();
                chooseRole = "3";
            }

        }

    }

    
    }


