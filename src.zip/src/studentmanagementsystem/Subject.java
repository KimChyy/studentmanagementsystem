/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author EJAT
 */
public class Subject {
    private String name;
    private String code;
    private int creditHrs;
    private Course course;
    

    public Subject() {
    }

    public Subject(String name, String code, int creditHrs, Course course) {
        this.name = name;
        this.code = code;
        this.creditHrs = creditHrs;
        //(Course >> Subject) composition. if course takde, then subject auto takde
        this.course = new Course(course.getName(), course.getCourseId(), course.getFaculty());
       
    }
    
     public Subject(String name, String code, int creditHrs) {
        this.name = name;
        this.code = code;
        this.creditHrs = creditHrs;
       
       
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getCreditHrs() {
        return creditHrs;
    }

    public void setCreditHrs(int creditHrs) {
        this.creditHrs = creditHrs;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

   
    
    
}
