/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author EJAT
 */
// (Admin -> Person) inheritance
public class Admin extends Person {

    private String name;
    private String email;
    private String phoneNo;
    private String adminId;
    private String password;

    public Admin() {
    }

    public Admin(String name, String email, String phoneNo, String adminId, String password) {
        this.name = name;
        this.email = email;
        this.phoneNo = phoneNo;
        this.adminId = adminId;
        this.password = password;
    }

    public Admin(String name, String email, String phoneNo, String adminId) {
        this.name = name;
        this.email = email;
        this.phoneNo = phoneNo;
        this.adminId = adminId;
    }
    public Admin(String name, String email, String phoneNo) {
        this.name = name;
        this.email = email;
        this.phoneNo = phoneNo;
        
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getPhoneNo() {
        return phoneNo;
    }

    @Override
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public void addStudent(Student student) {

    }

    public void manageStudent() {

    }

    public void addCourse(Course course) {

    }

    public void addFaculty(Faculty faculty) {

    }

    public void addSubject(Subject subject) {

    }

}
