/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsystem;

/**
 *
 * @author EJAT
 */
public class PersonFactory {
    
    public static Person getPerson(String type, String name, String email, String phoneNo) {
        
        Person per = null;
        if (type.equals("admin")) {
            per = new Admin(name, email, phoneNo);
            
        } else if (type.equals("student")) {
            per = new Student();
            ((Student) per).setName(name);
            ((Student) per).setEmail(email);
            ((Student) per).setPhoneNo(phoneNo);
           
        }
        
        return per;
    }
    
}
